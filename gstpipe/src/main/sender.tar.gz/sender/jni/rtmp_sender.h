#ifndef  J__RTMP_SEND__H
#define J__RTMP_SEND__H

#define ERR_SEND_FAILED -1
#define ERR_CONNECT_FAILED -2

#define INFO_CONNECT_FINISH 2

#endif
